# clarity
A CLI tool to give you clarity on your gpay expenses
